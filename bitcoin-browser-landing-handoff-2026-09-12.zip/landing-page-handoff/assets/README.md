# Brand asset references — not product screenshots

These files reproduce the existing `build/icon.png` and `build/icon.svg` for reference. They do not establish a new visual identity, represent product screenshots, or imply an application change.

## Publication blocker found during this handoff

The 1024 × 1024 PNG visibly renders an outlined missing-glyph rectangle where the Bitcoin symbol should appear. Do not use it in a landing-page hero, favicon, download badge or app-store graphic.

The SVG contains `<text>` with `font-family="DejaVu Sans, sans-serif"` and the Bitcoin Unicode character. Its glyph depends on the available rendering font. A corrected, font-independent vector outline and visually verified exports should be prepared and approved in a separate branding fix before publication. This handoff did not edit the application's icon or generated platform assets.

For now, Astra can use a plain-text **Bitcoin Browser** wordmark and the documented app colors. Do not invent a new logo, treat the missing-glyph box as intentional branding, or claim this reference is ready to ship.

## Third-party images

Project logos and inscription artwork found elsewhere in the repository are not copied into this asset pack. Their presence in discovery UI does not confer general promotional reuse rights or imply endorsement. Consult `docs/POPULAR_ASSET_LOGOS.md` and obtain the appropriate owner review before using them outside a genuine contextual product screenshot.
